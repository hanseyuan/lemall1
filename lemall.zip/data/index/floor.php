<?php
header("Content-Type:application/json;charset=UTF-8");
$output=[
    /*home:[],
    phone:[],
    parets:[],
    capacity:[]*/
];
require_once("../init.php");
$sql="SELECT title,details,pic,price,href FROM le_index_product WHERE home>0 order by
home LIMIT 7";
$output["home"]=sql_execute($sql);

$sql="SELECT title,details,pic,price,href FROM le_index_product WHERE phone>0 order by phone LIMIT 7";
$output["phone"]=sql_execute($sql);

$sql="SELECT title,details,pic,price,href FROM le_index_product WHERE parets>0 order by parets LIMIT 10";
$output["parets"]=sql_execute($sql);

$sql="SELECT title,details,pic,price,href FROM le_index_product WHERE capacity>0 order by capacity LIMIT 10";
$output["capacity"]=sql_execute($sql);

echo json_encode($output);
?>