<?php
    header('Content-Type:application/json;charset=UTF-8');
    require("../init.php");
    $sql = "SELECT * FROM le_index_carousel";
    $result=mysqli_query($conn, $sql);
    $row=mysqli_fetch_all($result,1);
    echo json_encode($row);
?>